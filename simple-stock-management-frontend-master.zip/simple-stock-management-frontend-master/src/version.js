const APP_VERSION = '[client 4.1.8.2]';
export default APP_VERSION;
